<?php
session_start();
require 'db_config.php'; // Подключение через PDO

// Обработка добавления услуги
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($name) && !empty($description) && !empty($price)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO services (name, description, price) VALUES (?, ?, ?)");
            $stmt->execute([$name, $description, $price]);
            header("Location: admin.php");
            exit;
        } catch (PDOException $e) {
            die("Ошибка добавления услуги: " . $e->getMessage());
        }
    } else {
        $error = "Все поля обязательны для заполнения.";
    }
}

// Обработка удаления услуги
if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM services WHERE id = ?");
        $stmt->execute([$deleteId]);
        header("Location: admin.php");
        exit;
    } catch (PDOException $e) {
        die("Ошибка удаления услуги: " . $e->getMessage());
    }
}

// Обработка редактирования услуги
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (!empty($name) && !empty($description) && !empty($price)) {
        try {
            $stmt = $pdo->prepare("UPDATE services SET name = ?, description = ?, price = ? WHERE id = ?");
            $stmt->execute([$name, $description, $price, $id]);
            header("Location: admin.php");
            exit;
        } catch (PDOException $e) {
            die("Ошибка редактирования услуги: " . $e->getMessage());
        }
    } else {
        $error = "Все поля обязательны для заполнения.";
    }
}

// Получение списка услуг
try {
    $stmt = $pdo->query("SELECT * FROM services");
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Ошибка выполнения запроса: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Админ-панель</h1>
    <h2>Список услуг</h2>
    <?php if (!empty($services)): ?>
        <table border="1" cellpadding="8">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Название услуги</th>
                    <th>Описание</th>
                    <th>Цена</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($services as $service): ?>
                    <tr>
                        <td><?= htmlspecialchars($service['id']) ?></td>
                        <td><?= htmlspecialchars($service['name']) ?></td>
                        <td><?= htmlspecialchars($service['description']) ?></td>
                        <td><?= number_format($service['price'], 2) ?> руб.</td>
                        <td>
                            <!-- Кнопка для редактирования -->
                            <form action="admin.php" method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="edit">
                                <input type="hidden" name="id" value="<?= $service['id'] ?>">
                                <input type="text" name="name" value="<?= htmlspecialchars($service['name']) ?>" required>
                                <input type="text" name="description" value="<?= htmlspecialchars($service['description']) ?>" required>
                                <input type="number" step="0.01" name="price" value="<?= htmlspecialchars($service['price']) ?>" required>
                                <button type="submit">Сохранить</button>
                            </form>

                            <!-- Кнопка для удаления -->
                            <a href="admin.php?delete_id=<?= $service['id'] ?>" onclick="return confirm('Вы уверены?')">Удалить</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Нет доступных услуг.</p>
    <?php endif; ?>

    <h2>Добавить новую услугу</h2>
    <form action="admin.php" method="POST">
        <input type="hidden" name="action" value="add">
        <label>Название услуги:</label><br>
        <input type="text" name="name" required><br><br>
        <label>Описание:</label><br>
        <textarea name="description" required></textarea><br><br>
        <label>Цена:</label><br>
        <input type="number" step="0.01" name="price" required><br><br>
        <button type="submit">Добавить</button>
    </form>

    <?php if (isset($error)): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>
</body>
</html>
